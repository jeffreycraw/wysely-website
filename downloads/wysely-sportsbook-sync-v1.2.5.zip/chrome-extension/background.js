// ─── Background Service Worker ───
// Captures sportsbook API request headers via webRequest API.
// Handles auto-sync via chrome.alarms and content script page-load triggers.
// Supports multiple providers (FanDuel, DraftKings).

importScripts(
  "lib/firebase-app-compat.js",
  "lib/firebase-auth-compat.js",
  "lib/firebase-firestore-compat.js",
  "shared/firebase-config.js",
  "shared/telemetry.js",
  "shared/sync-engine.js",
  "providers/provider-registry.js",
  "providers/fanduel.js",
  "providers/draftkings.js"
);

const LOG = "[Wysely BG]";

// ─── Firebase Init ───
if (!firebase.apps.length) {
  firebase.initializeApp(FIREBASE_CONFIG);
}
const auth = firebase.auth();
const db = firebase.firestore();

// ─── Auth State Tracking ───
let currentUser = null;
const authReadyPromise = new Promise((resolve) => {
  auth.onAuthStateChanged((user) => {
    currentUser = user;
    if (user) {
      console.log(LOG, "Auth: signed in as", user.email);
      chrome.storage.local.set({ firebaseUid: user.uid, firebaseEmail: user.email });
    } else {
      console.log(LOG, "Auth: signed out");
      chrome.storage.local.remove(["firebaseUid", "firebaseEmail"]);
    }
    resolve(user);
  });
});

// ─── Header Capture (FanDuel + DraftKings) ───

const capturedRequests = [];

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const url = details.url;

    // Skip static assets, tracking pixels, analytics, etc.
    if (/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)(\?|$)/i.test(url)) return;
    if (url.includes("google") || url.includes("gtm.") || url.includes("analytics")) return;
    if (url.includes("amplitude") || url.includes("braze") || url.includes("appsflyer")) return;
    if (url.includes("facebook") || url.includes("twitter") || url.includes("doubleclick")) return;
    if (url.includes("datadog") || url.includes("newrelic") || url.includes("sentry")) return;

    const headerObj = {};
    for (const h of details.requestHeaders || []) {
      headerObj[h.name] = h.value;
    }

    // Determine which provider this request is for
    let prefix = null;
    if (url.includes("fanduel.com")) prefix = "fd";
    else if (url.includes("draftkings.com")) prefix = "dk";

    const entry = {
      url: url,
      method: details.method,
      headers: headerObj,
      time: Date.now()
    };
    capturedRequests.push(entry);
    if (capturedRequests.length > 50) capturedRequests.shift();

    const hasAuthHeader = Object.keys(headerObj).some(h => {
      const lower = h.toLowerCase();
      return lower.includes("auth") || lower.includes("x-application") ||
             lower.includes("x-token") || lower === "authorization";
    });

    if (hasAuthHeader && prefix) {
      chrome.storage.local.set({
        [prefix + "CapturedHeaders"]: headerObj,
        [prefix + "CapturedUrl"]: url,
        [prefix + "CapturedTime"]: Date.now()
      });

      // Trigger auto-sync as soon as FanDuel auth headers are detected.
      // This fires within seconds of login, even on SPA navigation where
      // the content script doesn't re-run. DraftKings uses its own trigger
      // (draftkingsBetsReady) so we only do this for FanDuel here.
      if (prefix === "fd") {
        tryAutoSync("fdAuthDetected", 60 * 1000);
      }
    }
  },
  { urls: ["*://*.fanduel.com/*", "*://*.draftkings.com/*"] },
  ["requestHeaders", "extraHeaders"]
);

// ─── Auto-Sync: Alarm Setup ───
// reportInstallOnce comes from shared/telemetry.js.

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("autoSync", { periodInMinutes: 30 });
  console.log(LOG, "Auto-sync alarm created (every 30 min)");
  reportInstallOnce();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("autoSync", { periodInMinutes: 30 });
  console.log(LOG, "Auto-sync alarm ensured on startup");
  reportInstallOnce();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "autoSync") {
    await tryAutoSync("alarm");
  }
});

// ─── Auto-Sync: Core Logic ───

// In-memory guards. These exist because the storage-based lock below cannot
// stop a burst: reading storage is async, so several triggers arriving in the
// same moment all saw "not running" before any of them wrote the lock, and
// every one of them ran a full sync. One FanDuel login produced four.
//
// The service worker is single-threaded, so a plain variable set before the
// first await is genuinely atomic against other calls. Storage stays as the
// cross-restart record, since the worker can be torn down at any time.
let syncInFlight = false;
let lastSyncAt = 0;

async function tryAutoSync(trigger, minIntervalMs = 15 * 60 * 1000) {
  // ── Synchronous guards: no await between the check and the set ──
  if (syncInFlight) {
    console.log(LOG, "Sync already in progress, skipping");
    return;
  }
  if (Date.now() - lastSyncAt < minIntervalMs) {
    console.log(LOG, "Auto-sync skipped: last sync was", Math.round((Date.now() - lastSyncAt) / 1000), "sec ago");
    return;
  }
  syncInFlight = true;

  // Only cleared by whoever actually took it, so bailing out here never
  // releases a lock another worker is holding.
  let tookStorageLock = false;

  try {
    const settings = await chrome.storage.local.get([
      "autoSyncEnabled", "lastAutoSyncTime", "syncInProgress", "syncLockTime"
    ]);

    // Check if auto-sync is enabled (default: true)
    if (settings.autoSyncEnabled === false) {
      console.log(LOG, "Auto-sync disabled, skipping");
      return;
    }

    // Debounce: page-load triggers use a 60s minimum; alarm triggers use 15 minutes.
    // Takes the later of memory and storage, since a restarted worker starts at 0.
    const lastSync = Math.max(lastSyncAt, settings.lastAutoSyncTime || 0);
    lastSyncAt = lastSync;
    if (Date.now() - lastSync < minIntervalMs) {
      console.log(LOG, "Auto-sync skipped: last sync was", Math.round((Date.now() - lastSync) / 1000), "sec ago");
      return;
    }

    // Prevent concurrent syncs (with stale lock timeout)
    if (settings.syncInProgress) {
      const lockTime = settings.syncLockTime || 0;
      if (Date.now() - lockTime > 5 * 60 * 1000) {
        console.log(LOG, "Stale sync lock detected, clearing");
        await chrome.storage.local.set({ syncInProgress: false });
      } else {
        console.log(LOG, "Sync already in progress, skipping");
        return;
      }
    }

    // Wait for auth
    await authReadyPromise;
    if (!currentUser) {
      console.log(LOG, "No authenticated user, skipping auto-sync");
      return;
    }

    // Set lock
    await chrome.storage.local.set({ syncInProgress: true, syncLockTime: Date.now() });
    tookStorageLock = true;

    console.log(LOG, "Starting auto-sync (trigger:", trigger, ")");
    const result = await performSync(db, currentUser.uid, { silent: true });

    if (result.success) {
      console.log(LOG, "Auto-sync complete:", result.newBets, "new,", result.updatedBets, "updated");
      lastSyncAt = Date.now();
      await chrome.storage.local.set({ lastAutoSyncTime: lastSyncAt });

      // Set badge on extension icon if new bets found
      const totalChanges = result.newBets + result.updatedBets;
      if (totalChanges > 0) {
        chrome.action.setBadgeText({ text: String(totalChanges) });
        chrome.action.setBadgeBackgroundColor({ color: "#00A5A2" });
        // Clear badge after 5 minutes
        setTimeout(() => chrome.action.setBadgeText({ text: "" }), 5 * 60 * 1000);
      }
    } else {
      console.log(LOG, "Auto-sync skipped:", result.error);
    }
  } catch (error) {
    console.error(LOG, "Auto-sync error:", error.message);
  } finally {
    syncInFlight = false;
    if (tookStorageLock) {
      await chrome.storage.local.set({ syncInProgress: false });
    }
  }
}

// ─── Message Handlers ───

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Existing: captured headers for popup
  if (message.action === "getCapturedHeaders") {
    chrome.storage.local.get(
      ["fdCapturedHeaders", "fdCapturedUrl", "fdCapturedTime",
       "dkCapturedHeaders", "dkCapturedUrl", "dkCapturedTime"],
      (data) => {
        sendResponse({
          fanduel: {
            headers: data.fdCapturedHeaders || null,
            url: data.fdCapturedUrl || null,
            capturedAt: data.fdCapturedTime || 0,
            ageMs: data.fdCapturedTime ? Date.now() - data.fdCapturedTime : -1
          },
          draftkings: {
            headers: data.dkCapturedHeaders || null,
            url: data.dkCapturedUrl || null,
            capturedAt: data.dkCapturedTime || 0,
            ageMs: data.dkCapturedTime ? Date.now() - data.dkCapturedTime : -1
          },
          allCapturedUrls: capturedRequests.map(r => r.method + " " + r.url)
        });
      }
    );
    return true; // async sendResponse
  }

  // Content script: FanDuel page loaded → trigger auto-sync (60s debounce)
  if (message.action === "fanduelPageLoaded") {
    console.log(LOG, "FanDuel page loaded:", message.url);
    tryAutoSync("fanduelPageLoad", 60 * 1000);
    sendResponse({ ack: true });
    return false;
  }

  // Content script: DraftKings page loaded — just log, don't trigger sync yet.
  // DK delivers bet data via WebSocket AFTER page load, so syncing now would find no data.
  // The actual sync trigger comes from "draftkingsBetsReady" below.
  if (message.action === "draftkingsPageLoaded") {
    console.log(LOG, "DraftKings page loaded:", message.url);
    sendResponse({ ack: true });
    return false;
  }

  // Content script: DraftKings WebSocket bet data has been captured → NOW trigger auto-sync (60s debounce)
  if (message.action === "draftkingsBetsReady") {
    console.log(LOG, "DraftKings bet data ready — triggering auto-sync");
    tryAutoSync("draftkingsBetsReady", 60 * 1000);
    sendResponse({ ack: true });
    return false;
  }

  // Popup: get auto-sync status
  if (message.action === "getAutoSyncStatus") {
    chrome.storage.local.get(["autoSyncEnabled", "lastAutoSyncTime"], (data) => {
      sendResponse({
        enabled: data.autoSyncEnabled !== false, // default true
        lastSyncTime: data.lastAutoSyncTime || null
      });
    });
    return true;
  }

  // Popup: toggle auto-sync
  if (message.action === "setAutoSyncEnabled") {
    chrome.storage.local.set({ autoSyncEnabled: message.enabled });
    console.log(LOG, "Auto-sync", message.enabled ? "enabled" : "disabled");
    sendResponse({ ok: true });
    return false;
  }

  // Popup: acquire sync lock (for manual sync)
  if (message.action === "acquireSyncLock") {
    chrome.storage.local.get(["syncInProgress"], (data) => {
      if (data.syncInProgress) {
        sendResponse({ acquired: false });
      } else {
        chrome.storage.local.set({ syncInProgress: true, syncLockTime: Date.now() });
        sendResponse({ acquired: true });
      }
    });
    return true;
  }

  // Popup: release sync lock
  if (message.action === "releaseSyncLock") {
    chrome.storage.local.set({ syncInProgress: false });
    sendResponse({ ok: true });
    return false;
  }
});

console.log(LOG, "Service worker started. Listening for FanDuel + DraftKings requests. Auto-sync enabled.");
