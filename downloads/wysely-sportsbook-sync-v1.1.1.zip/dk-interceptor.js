// ─── DraftKings WebSocket Interceptor (MAIN World) ───
// Loaded via manifest.json content_scripts with world: "MAIN" at document_start.
// Patches WebSocket to capture bet data delivered via WebSocket messages.
// Stores captured data in window.__wyselyDKData for later retrieval.

(function() {
  if (window.__wyselyDKInterceptor) return;
  window.__wyselyDKInterceptor = true;
  window.__wyselyDKData = { bets: null, events: null, capturedAt: null };

  var NativeWebSocket = window.WebSocket;
  window.WebSocket = new Proxy(NativeWebSocket, {
    construct: function(target, args) {
      var ws = new target(args[0], args[1]);

      ws.addEventListener("message", function(event) {
        try {
          if (typeof event.data !== "string") return;
          var parsed = JSON.parse(event.data);
          if (parsed && parsed.result && parsed.result.initial && parsed.result.initial.bets) {
            var existing = window.__wyselyDKData || {};
            var prevBets = existing.bets || {};
            var prevEvents = existing.events || {};
            var newBets = parsed.result.initial.bets;
            var newEvents = parsed.result.initial.events || {};

            var merged = {};
            for (var k in prevBets) { if (prevBets.hasOwnProperty(k)) merged[k] = prevBets[k]; }
            for (var j in newBets) { if (newBets.hasOwnProperty(j)) merged[j] = newBets[j]; }

            var mergedEvents = {};
            for (var e in prevEvents) { if (prevEvents.hasOwnProperty(e)) mergedEvents[e] = prevEvents[e]; }
            for (var f in newEvents) { if (newEvents.hasOwnProperty(f)) mergedEvents[f] = newEvents[f]; }

            window.__wyselyDKData = {
              bets: merged,
              events: mergedEvents,
              capturedAt: Date.now()
            };
            console.log("[Wysely] Captured DK bet data:", Object.keys(merged).length, "bets,", Object.keys(mergedEvents).length, "events");

            // Signal content script (ISOLATED world) that bet data is ready for sync.
            // CustomEvents on document are visible across MAIN and ISOLATED worlds.
            document.dispatchEvent(new CustomEvent("wysely-dk-data-ready"));
          }
        } catch (e) { /* ignore parse errors for non-JSON messages */ }
      });

      return ws;
    }
  });

  console.log("[Wysely] DK WebSocket interceptor installed");
})();
