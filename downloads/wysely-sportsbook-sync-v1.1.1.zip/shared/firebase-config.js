// ─── Shared Firebase Configuration ───
// Used by both popup.js (via <script> tag) and background.js (via importScripts).
// No ES module exports — must be compatible with importScripts().

// eslint-disable-next-line no-unused-vars
var FIREBASE_CONFIG = {
  apiKey: "AIzaSyDXmLNKU9e_-0XKBrPiVAJwwMbCrHsnWe4",
  authDomain: "betting-performance-ed10a.firebaseapp.com",
  projectId: "betting-performance-ed10a",
  storageBucket: "betting-performance-ed10a.firebasestorage.app",
  messagingSenderId: "602721352917",
  appId: "1:602721352917:web:345b8e0cfb1bad6f67f65c",
  measurementId: "G-18S9LWQ7QQ"
};
