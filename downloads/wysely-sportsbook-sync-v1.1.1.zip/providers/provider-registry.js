// ─── Provider Registry ───
// Maps provider names to their adapter modules.
// Each provider must define: name, displayName, tabUrlPattern,
// fetchBetsFromPage (injected function), mapBets (data mapper), storageKeyPrefix

const PROVIDERS = {};

function registerProvider(provider) {
  PROVIDERS[provider.name] = provider;
}

function getProvider(name) {
  return PROVIDERS[name] || null;
}

function getAllProviders() {
  return Object.values(PROVIDERS);
}
