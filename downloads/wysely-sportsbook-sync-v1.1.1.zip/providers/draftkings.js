// ─── DraftKings Provider Adapter ───

registerProvider({
  name: "draftkings",
  displayName: "DraftKings",
  tabUrlPattern: "*://*.draftkings.com/*",
  storageKeyPrefix: "dk",
  pageLoadedMessage: "draftkingsPageLoaded",

  // The function injected into DraftKings' MAIN world to fetch bets
  fetchBetsFromPage: fetchDraftKingsBetsFromPage,

  // Maps raw DraftKings bets to our standard schema
  mapBets: mapDraftKingsBets
});

// ─── DraftKings Data Mapper ───

// eslint-disable-next-line no-unused-vars
function mapDraftKingsBets(response) {
  const betsObj = response.bets || {};
  const eventsObj = response.events || {};

  // bets may be an object keyed by betId or an array
  const betsArray = Array.isArray(betsObj) ? betsObj : Object.values(betsObj);
  return betsArray.map(bet => mapDraftKingsBet(bet, eventsObj)).filter(bet => bet.providerBetId);
}

function mapDraftKingsBet(dkBet, events) {
  const selections = dkBet.selections || [];
  const isParlay = (dkBet.type || "").toLowerCase() !== "single" && selections.length > 1;

  const legs = selections.map(sel => {
    const event = events[sel.eventId] || {};
    const sportFromId = mapDKSportId(event.sportId, event.eventDisplayName);
    const resolvedSport = sportFromId !== "Other" ? sportFromId : detectSportFromEvent(event.eventDisplayName || "", "");

    return {
      sportRaw: resolvedSport,
      betTypeRaw: detectDKBetType(sel, resolvedSport),
      resultRaw: mapDKSelectionResult(sel),
      legDescription: buildDKLegDescription(sel),
      odds: parseDKOdds(sel.displayOdds),
      eventDescription: event.eventDisplayName || null
    };
  });

  // Get event info for the first selection
  const firstEvent = selections.length > 0 ? (events[selections[0].eventId] || {}) : {};

  return {
    providerBetId: String(dkBet.betId || dkBet.receiptId || ""),
    source: "draftkings",
    sportRaw: isParlay ? detectPrimarySport(legs) : (legs[0]?.sportRaw || mapDKSportId(firstEvent.sportId, firstEvent.eventDisplayName)),
    betTypeRaw: isParlay ? "Parlay" : (legs[0]?.betTypeRaw || "Other"),
    statusRaw: mapDKBetStatus(dkBet),
    stake: parseFloat(dkBet.stake || 0),
    odds: parseDKOdds(dkBet.displayOdds),
    potentialPayout: parseFloat(dkBet.potentialReturns || 0),
    actualPayout: extractDKActualPayout(dkBet),
    betDescription: buildBetDescription(legs, isParlay),
    notes: null,
    eventDate: parseDate(firstEvent.eventStartDate || dkBet.placementDate),
    eventDescription: legs[0]?.eventDescription || firstEvent.eventDisplayName || null,
    createdAt: parseDate(dkBet.placementDate),
    updatedAt: parseDate(dkBet.settlementDate || dkBet.placementDate),
    legs: isParlay ? legs : [],
    syncedAt: new Date().toISOString()
  };
}

// ─── DraftKings Sport Mapping ───

const DK_SPORT_MAP = {
  "1": "Soccer",
  "2": "NBA",       // Basketball — may be NCAAB, disambiguated by event name
  "3": "NFL",       // Football — may be NCAAF, disambiguated by event name
  "4": "NHL",
  "5": "MMA",
  "6": "Tennis",
  "7": "MLB",
  "9": "Golf",
  "10": "Soccer",   // International soccer
  "11": "MMA",
  "12": "NASCAR",
  "13": "Soccer",
  "14": "Auto Racing"
};

function mapDKSportId(sportId, eventName) {
  if (!sportId) return "Other";
  const mapped = DK_SPORT_MAP[String(sportId)];
  if (!mapped) return "Other";

  // Disambiguate basketball: NBA vs NCAAB
  if (mapped === "NBA" && eventName) {
    const upper = eventName.toUpperCase();
    if (upper.includes("NCAA") || upper.includes("COLLEGE") || upper.includes("MARCH MADNESS")) {
      return "NCAAB";
    }
    // Check if it looks like college teams (no NBA team keywords)
    const hasNBATeam = SPORT_KEYWORDS.NBA.some(kw => upper.includes(kw.toUpperCase()));
    if (!hasNBATeam) {
      const hasNCAABKeyword = SPORT_KEYWORDS.NCAAB.some(kw => upper.includes(kw.toUpperCase()));
      if (hasNCAABKeyword) return "NCAAB";
    }
  }

  // Disambiguate football: NFL vs NCAAF
  if (mapped === "NFL" && eventName) {
    const upper = eventName.toUpperCase();
    if (upper.includes("NCAA") || upper.includes("COLLEGE") || upper.includes("BOWL") ||
        upper.includes("CFP")) {
      return "NCAAF";
    }
    const hasNFLTeam = SPORT_KEYWORDS.NFL.some(kw => upper.includes(kw.toUpperCase()));
    if (!hasNFLTeam) {
      const hasNCAAFKeyword = SPORT_KEYWORDS.NCAAF.some(kw => upper.includes(kw.toUpperCase()));
      if (hasNCAAFKeyword) return "NCAAF";
    }
  }

  return mapped;
}

// ─── DraftKings Bet Type Detection ───

function detectDKBetType(selection, sport) {
  const market = (selection.marketDisplayName || "").toUpperCase();
  const points = selection.points || null;

  // Auto racing / motorsport: ALL individual driver outcomes are Player Props
  // Check this FIRST — before shared detection, which would misclassify
  // championship bets as Futures
  if (sport === "Auto Racing" || sport === "NASCAR") {
    return "Player Prop";
  }

  // Use the shared detectBetType for all other sports
  const sharedResult = detectBetType({
    marketDesc: selection.marketDisplayName || "",
    selectionName: selection.selectionDisplayName || "",
    handicap: points
  });

  if (sharedResult !== "Other") return sharedResult;

  // Generic "Outright Winner" markets (common in DK for individual sports) → Player Prop
  if (market.includes("OUTRIGHT") || market.includes("RACE WINNER")) {
    return "Player Prop";
  }

  return "Other";
}

// ─── DraftKings Odds Parsing ───

function parseDKOdds(displayOdds) {
  if (displayOdds == null) return -110;
  if (typeof displayOdds === "number") return displayOdds;

  const str = String(displayOdds);
  // DK uses special minus sign (U+2212 −) and en-dash (U+2013 –) instead of regular hyphen
  const cleaned = str.replace(/[\u2212\u2013\u2014]/g, "-").replace(/[^0-9+\-]/g, "");
  const num = parseInt(cleaned, 10);
  return isNaN(num) ? -110 : num;
}

// ─── DraftKings Status Mapping ───

function mapDKBetStatus(dkBet) {
  const status = (dkBet.status || "").toLowerCase();

  if (status === "settled") {
    const ss = (dkBet.settlementStatus || "").toLowerCase();
    if (ss === "won" || ss === "win") return "Won";
    if (ss === "lost" || ss === "lose") return "Lost";
    if (ss === "push" || ss === "pushed") return "Push";
    if (ss === "void" || ss === "voided" || ss === "cancelled" || ss === "canceled") return "Void";
    if (ss === "cashedout" || ss === "cashed out" || ss === "cashout") return "Cashed Out";

    // Fallback: compare returns vs stake
    const returns = parseFloat(dkBet.returns || 0);
    const stake = parseFloat(dkBet.stake || 0);
    if (returns > stake) return "Won";
    if (returns === 0) return "Lost";
    if (Math.abs(returns - stake) < 0.01) return "Push";
    return "Lost";
  }

  if (status === "unsettled" || status === "open" || status === "pending") {
    return "Pending";
  }

  if (status === "cashedout" || status === "cashed_out") {
    return "Cashed Out";
  }

  return "Pending";
}

function mapDKSelectionResult(selection) {
  const status = (selection.settlementStatus || selection.status || "").toLowerCase();
  const map = {
    "won": "Won", "win": "Won",
    "lost": "Lost", "lose": "Lost",
    "push": "Push", "pushed": "Push",
    "void": "Void", "voided": "Void",
    "open": "Pending", "pending": "Pending"
  };
  return map[status] || "Pending";
}

// ─── DraftKings Payout ───

function extractDKActualPayout(dkBet) {
  const status = mapDKBetStatus(dkBet);
  if (status === "Pending") return null;

  const returns = parseFloat(dkBet.returns);
  if (!isNaN(returns)) {
    if (status === "Won") return returns;
    if (status === "Lost") return 0;
    if (status === "Push") return parseFloat(dkBet.stake || 0);
    if (status === "Cashed Out") return returns;
    return returns;
  }

  if (status === "Lost") return 0;
  if (status === "Push") return parseFloat(dkBet.stake || 0);
  return null;
}

// ─── DraftKings Description ───

function buildDKLegDescription(selection) {
  const parts = [];
  if (selection.selectionDisplayName) parts.push(selection.selectionDisplayName);
  if (selection.marketDisplayName) parts.push(selection.marketDisplayName);
  if (selection.points != null) {
    const p = parseFloat(selection.points);
    parts.push(p >= 0 ? `+${p}` : `${p}`);
  }
  return parts.join(" – ") || "Bet";
}

// ─── DraftKings Page Script (MAIN World) ───
// This function runs via chrome.scripting.executeScript in the DraftKings page's context.
// IMPORTANT: Must be entirely self-contained — no external references.
// Reads bet data captured by the WebSocket interceptor (injected by content-dk.js).

// eslint-disable-next-line no-unused-vars
async function fetchDraftKingsBetsFromPage() {
  const LOG = "[Wysely]";

  try {
    // Check for WebSocket-intercepted bet data
    const dkData = window.__wyselyDKData;

    if (dkData && dkData.bets && dkData.capturedAt) {
      const ageMinutes = (Date.now() - dkData.capturedAt) / 60000;
      console.log(LOG, "Found DK bet data captured", Math.round(ageMinutes), "min ago");

      if (ageMinutes > 30) {
        return {
          success: false,
          error: "DraftKings bet data is stale (" + Math.round(ageMinutes) + " min old). " +
                 "Please refresh the DraftKings page or navigate to 'My Bets' and try again."
        };
      }

      const betsCount = typeof dkData.bets === "object" ? Object.keys(dkData.bets).length : 0;
      const eventsCount = typeof dkData.events === "object" ? Object.keys(dkData.events).length : 0;
      console.log(LOG, "DK data:", betsCount, "bets,", eventsCount, "events");

      return {
        success: true,
        bets: dkData.bets,
        events: dkData.events || {},
        summary: { total: betsCount }
      };
    }

    // No data captured yet — try to set up the interceptor and guide the user
    if (!window.__wyselyDKInterceptor) {
      // Install WebSocket interceptor now (better late than never)
      setupDKWebSocketInterceptor();
      console.log(LOG, "Installed DK WebSocket interceptor (late)");
    }

    return {
      success: false,
      error: "No DraftKings bet data found. Please navigate to the 'My Bets' tab on DraftKings, " +
             "wait for your bets to load, then click 'Pull My Bets' again."
    };

  } catch (error) {
    console.error(LOG, error);
    return { success: false, error: error.message };
  }

  function setupDKWebSocketInterceptor() {
    if (window.__wyselyDKInterceptor) return;
    window.__wyselyDKInterceptor = true;
    window.__wyselyDKData = { bets: null, events: null, capturedAt: null };

    var NativeWebSocket = window.WebSocket;
    window.WebSocket = new Proxy(NativeWebSocket, {
      construct: function(target, args) {
        var ws = new target(args[0], args[1]);
        ws.addEventListener("message", function(event) {
          try {
            if (typeof event.data !== "string") return;
            var parsed = JSON.parse(event.data);
            if (parsed && parsed.result && parsed.result.initial && parsed.result.initial.bets) {
              var existing = window.__wyselyDKData || {};
              var prevBets = existing.bets || {};
              var prevEvents = existing.events || {};
              var newBets = parsed.result.initial.bets;
              var newEvents = parsed.result.initial.events || {};
              var merged = {};
              for (var k in prevBets) { if (prevBets.hasOwnProperty(k)) merged[k] = prevBets[k]; }
              for (var j in newBets) { if (newBets.hasOwnProperty(j)) merged[j] = newBets[j]; }
              var mergedEvents = {};
              for (var e in prevEvents) { if (prevEvents.hasOwnProperty(e)) mergedEvents[e] = prevEvents[e]; }
              for (var f in newEvents) { if (newEvents.hasOwnProperty(f)) mergedEvents[f] = newEvents[f]; }
              window.__wyselyDKData = {
                bets: merged,
                events: mergedEvents,
                capturedAt: Date.now()
              };
              console.log("[Wysely] Captured DK bet data:", Object.keys(merged).length, "bets,", Object.keys(mergedEvents).length, "events");
            }
          } catch (e) { /* ignore parse errors for non-JSON messages */ }
        });
        return ws;
      }
    });
  }
}
