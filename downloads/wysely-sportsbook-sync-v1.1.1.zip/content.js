// ─── FanDuel Content Script ───
// Handles ping/presence detection and notifies background for auto-sync.
// The actual API fetching is done via chrome.scripting.executeScript
// from sync-engine.js with world: "MAIN" to bypass page CSP.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "ping") {
    sendResponse({ status: "ok", hostname: window.location.hostname });
    return false;
  }
});

// Notify background.js that a FanDuel page has loaded → triggers auto-sync (debounced)
chrome.runtime.sendMessage({ action: "fanduelPageLoaded", url: window.location.href })
  .catch(() => {}); // Silently ignore if background isn't ready

console.log("[Wysely] Content script loaded on", window.location.hostname);
