// ─── DraftKings Content Script (ISOLATED World) ───
// Handles ping/presence detection and notifies background for auto-sync.
// The WebSocket interceptor runs separately via dk-interceptor.js in MAIN world.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "ping") {
    sendResponse({ status: "ok", hostname: window.location.hostname });
    return false;
  }
});

// Notify background.js that a DraftKings page has loaded (for header capture, etc.)
chrome.runtime.sendMessage({ action: "draftkingsPageLoaded", url: window.location.href })
  .catch(() => {}); // Silently ignore if background isn't ready

// Listen for bet data captured by the WebSocket interceptor (MAIN world).
// This CustomEvent fires on document, which is shared across MAIN and ISOLATED worlds.
// Debounce: DK may send multiple WebSocket messages in quick succession as different
// bet categories load. Wait 2 seconds for all data to settle before triggering sync.
let dkDataReadyTimer = null;
document.addEventListener("wysely-dk-data-ready", () => {
  clearTimeout(dkDataReadyTimer);
  dkDataReadyTimer = setTimeout(() => {
    console.log("[Wysely] DK bet data ready — notifying background for auto-sync");
    chrome.runtime.sendMessage({ action: "draftkingsBetsReady" })
      .catch(() => {});
  }, 2000);
});

console.log("[Wysely] DK content script loaded on", window.location.hostname);
