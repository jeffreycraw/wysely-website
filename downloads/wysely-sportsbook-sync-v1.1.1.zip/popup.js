// ─── Popup Controller ───
// Handles Firebase Auth, manual bet pulling (via shared sync-engine.js),
// reclassification, and auto-sync toggle.

// ─── Firebase Init ───
// FIREBASE_CONFIG is loaded from shared/firebase-config.js
firebase.initializeApp(FIREBASE_CONFIG);
const auth = firebase.auth();
const db = firebase.firestore();

// ─── DOM Elements ───
const authView = document.getElementById("auth-view");
const mainView = document.getElementById("main-view");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const signInBtn = document.getElementById("sign-in-btn");
const authError = document.getElementById("auth-error");
const userEmailSpan = document.getElementById("user-email");
const pullBetsBtn = document.getElementById("pull-bets-btn");
const pullBtnText = document.getElementById("pull-btn-text");
const pullSpinner = document.getElementById("pull-spinner");
const statusDiv = document.getElementById("status");
const signOutBtn = document.getElementById("sign-out-btn");
const reclassifyBtn = document.getElementById("reclassify-btn");
const reclassifyBtnText = document.getElementById("reclassify-btn-text");
const reclassifySpinner = document.getElementById("reclassify-spinner");
const autoSyncToggle = document.getElementById("auto-sync-toggle");
const lastSyncTimeSpan = document.getElementById("last-sync-time");

// ─── Clear badge on popup open ───
chrome.action.setBadgeText({ text: "" });

// ─── Auth State ───

auth.onAuthStateChanged((user) => {
  if (user) {
    showMainView(user);
  } else {
    showAuthView();
  }
});

function showAuthView() {
  authView.classList.remove("hidden");
  mainView.classList.add("hidden");
  authError.classList.add("hidden");
  emailInput.value = "";
  passwordInput.value = "";
}

function showMainView(user) {
  authView.classList.add("hidden");
  mainView.classList.remove("hidden");
  userEmailSpan.textContent = user.email;
  loadAutoSyncStatus();
}

// ─── Sign In ───

signInBtn.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) {
    showAuthError("Please enter email and password.");
    return;
  }

  signInBtn.disabled = true;
  signInBtn.textContent = "Signing in...";
  authError.classList.add("hidden");

  try {
    await auth.signInWithEmailAndPassword(email, password);
  } catch (error) {
    showAuthError(friendlyAuthError(error.code));
  } finally {
    signInBtn.disabled = false;
    signInBtn.textContent = "Sign In";
  }
});

// Allow Enter key to submit
passwordInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") signInBtn.click();
});

emailInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") passwordInput.focus();
});

function showAuthError(message) {
  authError.textContent = message;
  authError.classList.remove("hidden");
}

function friendlyAuthError(code) {
  const messages = {
    "auth/user-not-found": "No account found with this email.",
    "auth/wrong-password": "Incorrect password.",
    "auth/invalid-email": "Invalid email address.",
    "auth/too-many-requests": "Too many attempts. Try again later.",
    "auth/invalid-credential": "Invalid email or password.",
    "auth/network-request-failed": "Network error. Check your connection."
  };
  return messages[code] || "Sign in failed. Please try again.";
}

// ─── Reclassify Bet Types Migration ───

reclassifyBtn.addEventListener("click", async () => {
  const user = auth.currentUser;
  if (!user) {
    setStatus("error", "You must be signed in to reclassify bets.");
    return;
  }

  reclassifyBtn.disabled = true;
  reclassifyBtnText.textContent = "Reclassifying...";
  reclassifySpinner.classList.remove("hidden");
  setStatus("info", "Scanning bets for reclassification...");
  statusDiv.classList.remove("hidden");

  try {
    const result = await reclassifyBetTypes(user.uid);
    if (result.updated === 0) {
      setStatus("info", `Scanned ${result.scanned} bets — all bet types are already correct. No changes needed.`);
    } else {
      setStatus("success", `Done! Reclassified ${result.updated} of ${result.scanned} bets (${result.legs} parlay legs updated).`);
    }
  } catch (error) {
    console.error("Reclassify error:", error);
    setStatus("error", `Reclassification failed: ${error.message}`);
  } finally {
    reclassifyBtn.disabled = false;
    reclassifyBtnText.textContent = "Reclassify Bet Types";
    reclassifySpinner.classList.add("hidden");
  }
});

/**
 * Reclassify existing Firestore bets using updated bet type detection logic.
 */
async function reclassifyBetTypes(uid) {
  const betsRef = db.collection("users").doc(uid).collection("bets");
  const snapshot = await betsRef.get();

  let scanned = 0;
  let updated = 0;
  let legsUpdated = 0;
  const batchSize = 450;
  let currentBatch = db.batch();
  let batchCount = 0;

  for (const doc of snapshot.docs) {
    scanned++;
    const data = doc.data();
    let changed = false;

    if (data.betTypeRaw === "Parlay" && Array.isArray(data.legs)) {
      const updatedLegs = data.legs.map(leg => {
        if (leg.betTypeRaw === "Player Prop" || leg.betTypeRaw === "Futures") {
          const newType = reclassifyFromDescription(leg.legDescription || "", leg.betTypeRaw);
          if (newType && newType !== leg.betTypeRaw) {
            legsUpdated++;
            changed = true;
            return { ...leg, betTypeRaw: newType };
          }
        }
        return leg;
      });

      if (changed) {
        currentBatch.update(doc.ref, { legs: updatedLegs, updatedAt: new Date().toISOString() });
        updated++;
        batchCount++;
      }
    } else if (data.betTypeRaw === "Player Prop" || data.betTypeRaw === "Futures") {
      const newType = reclassifyFromDescription(data.betDescription || "", data.betTypeRaw);
      if (newType && newType !== data.betTypeRaw) {
        currentBatch.update(doc.ref, { betTypeRaw: newType, updatedAt: new Date().toISOString() });
        updated++;
        batchCount++;
      }
    }

    if (batchCount >= batchSize) {
      await currentBatch.commit();
      currentBatch = db.batch();
      batchCount = 0;
    }
  }

  if (batchCount > 0) {
    await currentBatch.commit();
  }

  return { scanned, updated, legs: legsUpdated };
}

function reclassifyFromDescription(description, currentType) {
  if (!description) return null;
  const d = description.toUpperCase();

  if (currentType === "Player Prop") {
    if (d.includes("YARDS") || d.includes("COMPLETIONS") || d.includes("ATTEMPTS") ||
        d.includes("RECEPTIONS") || d.includes("REBOUNDS") || d.includes("ASSISTS") ||
        d.includes("POINTS") || d.includes("3-POINT") || d.includes("THREE POINT") ||
        d.includes("STEALS") || d.includes("BLOCKS") || d.includes("STRIKEOUTS") ||
        d.includes("HITS") || d.includes("BASES") || d.includes("GOALS") ||
        d.includes("SHOTS") || d.includes("TACKLES") || d.includes("HOME RUNS") ||
        d.includes("PASSING") || d.includes("RUSHING") || d.includes("RECEIVING")) {
      return "Over/Under";
    }
  }

  if (currentType === "Futures") {
    if (d.includes("SEASON WINS") || d.includes("WIN TOTAL") || d.includes("WINS O/U")) {
      return "Over/Under";
    }
  }

  return null;
}

// ─── Sign Out ───

signOutBtn.addEventListener("click", async () => {
  try {
    await auth.signOut();
  } catch (error) {
    console.error("Sign out error:", error);
  }
});

// ─── Pull Bets (uses shared performSync from sync-engine.js) ───

pullBetsBtn.addEventListener("click", async () => {
  setPulling(true);
  setStatus("info", "Connecting to sportsbooks...");

  try {
    // Acquire sync lock to prevent concurrent auto-sync
    const lockResult = await chrome.runtime.sendMessage({ action: "acquireSyncLock" }).catch(() => ({ acquired: true }));
    if (!lockResult.acquired) {
      setStatus("info", "An auto-sync is currently in progress. Please wait a moment and try again.");
      setPulling(false);
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      setStatus("error", "You've been signed out. Please sign in again.");
      setPulling(false);
      await chrome.runtime.sendMessage({ action: "releaseSyncLock" }).catch(() => {});
      return;
    }

    setStatus("info", "Pulling your bets...");
    const result = await performSync(db, user.uid, { silent: false });

    // Build detailed success message
    let successMsg = `Done! ${result.newBets} new bets added, ${result.updatedBets} updated, ${result.skippedBets} unchanged. Total: ${result.total} bets synced.`;

    // Note any provider errors alongside successful syncs
    if (result.errors && result.errors.length > 0) {
      const errorProviders = result.errors
        .filter(e => e.error !== "no_tab")
        .map(e => e.provider);
      if (errorProviders.length > 0) {
        successMsg += ` (Note: ${errorProviders.join(", ")} had errors)`;
      }
    }

    setStatus("success", successMsg);

    // Update last sync time display
    loadAutoSyncStatus();

  } catch (error) {
    console.error("Pull bets error:", error);
    if (error.message.includes("No sportsbook tab")) {
      setStatus("error", "No sportsbook tabs found. Please open FanDuel or DraftKings Sportsbook in a browser tab and make sure you're signed in.");
    } else {
      setStatus("error", "Error pulling bets. " + error.message);
    }
  } finally {
    setPulling(false);
    await chrome.runtime.sendMessage({ action: "releaseSyncLock" }).catch(() => {});
  }
});

function setPulling(pulling) {
  pullBetsBtn.disabled = pulling;
  pullBtnText.textContent = pulling ? "Pulling..." : "Pull My Bets";
  if (pulling) {
    pullSpinner.classList.remove("hidden");
  } else {
    pullSpinner.classList.add("hidden");
  }
}

function setStatus(type, message) {
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
  statusDiv.classList.remove("hidden");
}

// ─── Auto-Sync Controls ───

async function loadAutoSyncStatus() {
  try {
    const status = await chrome.runtime.sendMessage({ action: "getAutoSyncStatus" });
    if (autoSyncToggle) autoSyncToggle.checked = status.enabled;
    if (lastSyncTimeSpan) {
      if (status.lastSyncTime) {
        const ago = Math.round((Date.now() - status.lastSyncTime) / 60000);
        lastSyncTimeSpan.textContent = ago < 1 ? "Last sync: just now" : `Last sync: ${ago} min ago`;
      } else {
        lastSyncTimeSpan.textContent = "";
      }
    }
  } catch (e) {
    console.log("Could not load auto-sync status:", e.message);
  }
}

if (autoSyncToggle) {
  autoSyncToggle.addEventListener("change", async () => {
    try {
      await chrome.runtime.sendMessage({ action: "setAutoSyncEnabled", enabled: autoSyncToggle.checked });
    } catch (e) {
      console.log("Could not update auto-sync setting:", e.message);
    }
  });
}
