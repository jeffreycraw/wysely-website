// ─── Telemetry ───
// Two counters, both anonymous: how many browsers the extension is installed
// in, and how many of those ever completed a sync. Download-link clicks were
// the previous proxy for the first number and were almost entirely crawlers.
//
// Nothing identifying is sent. The installId is random, generated locally, and
// is not the Firebase uid or the user's email.
//
// Loaded by both background.js (importScripts) and popup.html (script tag),
// because a sync can be started from either.

const TELEMETRY_URL = "https://app.wyse-ly.com/api/extension-installed";

async function getInstallId() {
  const stored = await chrome.storage.local.get("installId");
  if (stored.installId) return stored.installId;
  const installId = crypto.randomUUID();
  await chrome.storage.local.set({ installId });
  return installId;
}

async function postTelemetry(event, extra = {}) {
  const installId = await getInstallId();
  await fetch(TELEMETRY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      installId,
      event,
      version: chrome.runtime.getManifest().version,
      ...extra,
    }),
  });
}

// Fires once per browser, the first time the service worker runs.
// Guarded by the stored flag rather than onInstalled's "install" reason,
// because loading an unpacked extension fires that on every reload.
async function reportInstallOnce() {
  try {
    const flags = await chrome.storage.local.get("installReported");
    if (flags.installReported) return;
    await chrome.storage.local.set({ installReported: true });
    await postTelemetry("installed");
    console.log("[Wysely Telemetry] Install reported");
  } catch (err) {
    console.log("[Wysely Telemetry] Install ping skipped:", err.message);
  }
}

// Fires once per browser, the first time a sync actually brings back bets.
// A successful sync that returns nothing is not activation.
async function reportActivationOnce(betCount) {
  try {
    if (!betCount || betCount < 1) return;
    const flags = await chrome.storage.local.get("activationReported");
    if (flags.activationReported) return;
    await chrome.storage.local.set({ activationReported: true });
    await postTelemetry("activated", { betCount });
    console.log("[Wysely Telemetry] Activation reported");
  } catch (err) {
    console.log("[Wysely Telemetry] Activation ping skipped:", err.message);
  }
}
