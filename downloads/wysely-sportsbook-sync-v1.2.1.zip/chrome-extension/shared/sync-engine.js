// ─── Shared Sync Engine ───
// Provider-agnostic sync orchestrator and shared utilities.
// No ES module exports — compatible with importScripts() and <script> tags.
// All functions are plain globals.

// ─── Sync Orchestration ───

/**
 * Main sync orchestration: find provider tabs → inject fetch → map → save to Firestore.
 * Loops through all registered providers. Skips providers with no open tab.
 * @param {object} db - Firestore database reference
 * @param {string} uid - Firebase user ID
 * @param {object} [options] - { silent: boolean } — if true, return error object instead of throwing
 * @returns {Promise<{success, newBets, updatedBets, skippedBets, total, providerResults, errors}>}
 */
// eslint-disable-next-line no-unused-vars
async function performSync(db, uid, options = {}) {
  const LOG = "[Wysely Sync]";
  const providers = getAllProviders();
  const results = [];
  const errors = [];

  for (const provider of providers) {
    try {
      const result = await syncProvider(db, uid, provider, options);
      results.push(result);
    } catch (error) {
      console.error(LOG, provider.displayName, "sync error:", error.message);
      errors.push({ provider: provider.name, error: error.message });
    }
  }

  const successResults = results.filter(r => r.success);
  const totalNew = results.reduce((sum, r) => sum + (r.newBets || 0), 0);
  const totalUpdated = results.reduce((sum, r) => sum + (r.updatedBets || 0), 0);
  const totalSkipped = results.reduce((sum, r) => sum + (r.skippedBets || 0), 0);
  const totalBets = results.reduce((sum, r) => sum + (r.total || 0), 0);

  // If no providers synced at all (no tabs found for any provider)
  if (successResults.length === 0) {
    const noTabResults = results.filter(r => r.error === "no_tab");
    if (noTabResults.length === results.length && results.length > 0) {
      // All providers had no tab
      const msg = "No sportsbook tabs found. Please open FanDuel or DraftKings Sportsbook in a browser tab and make sure you're signed in.";
      if (options.silent) return { success: false, error: msg, newBets: 0, updatedBets: 0, skippedBets: 0, total: 0 };
      throw new Error(msg);
    }
    // Some providers had other errors
    const firstError = errors[0]?.error || results.find(r => r.error && r.error !== "no_tab")?.error || "Sync failed.";
    if (options.silent) return { success: false, error: firstError, newBets: 0, updatedBets: 0, skippedBets: 0, total: 0 };
    throw new Error(firstError);
  }

  return {
    success: true,
    newBets: totalNew,
    updatedBets: totalUpdated,
    skippedBets: totalSkipped,
    total: totalBets,
    providerResults: results,
    errors: errors
  };
}

/**
 * Sync a single provider: find tab → inject fetch → map → save.
 */
async function syncProvider(db, uid, provider, options = {}) {
  const LOG = "[Wysely Sync]";

  // 1. Find provider tab
  const tabs = await chrome.tabs.query({ url: provider.tabUrlPattern });
  if (tabs.length === 0) {
    console.log(LOG, provider.displayName, "- no tab found, skipping");
    return { success: false, provider: provider.name, error: "no_tab", newBets: 0, updatedBets: 0, skippedBets: 0, total: 0 };
  }
  const tab = tabs[0];

  // 2. Get captured headers (provider may or may not need these)
  const prefix = provider.storageKeyPrefix;
  const headerKey = prefix + "CapturedHeaders";
  const timeKey = prefix + "CapturedTime";
  const stored = await chrome.storage.local.get([headerKey, timeKey]);
  let capturedAuthHeaders = null;

  if (stored[headerKey] && stored[timeKey] && (Date.now() - stored[timeKey] < 1800000)) {
    capturedAuthHeaders = {};
    const skipHeaders = ["host", "connection", "content-length", "user-agent", "cookie",
                         "origin", "referer", "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform",
                         "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site"];
    for (const [name, value] of Object.entries(stored[headerKey])) {
      if (!skipHeaders.includes(name.toLowerCase())) capturedAuthHeaders[name] = value;
    }
  }

  // 3. Inject fetchBetsFromPage into provider's tab (MAIN world)
  console.log(LOG, "Injecting fetch script into", provider.displayName, "tab", tab.id);
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: provider.fetchBetsFromPage,
    args: [capturedAuthHeaders]
  });

  const response = results?.[0]?.result;
  if (!response || !response.success) {
    const errorMsg = response?.error || `Failed to pull bets from ${provider.displayName}.`;
    if (options.silent) return { success: false, provider: provider.name, error: errorMsg, newBets: 0, updatedBets: 0, skippedBets: 0, total: 0 };
    throw new Error(errorMsg);
  }

  // 4. Map and save
  console.log(LOG, provider.displayName, "- mapping bets...");
  const mappedBets = provider.mapBets(response);
  const result = await saveBetsToFirestore(db, uid, mappedBets);

  console.log(LOG, provider.displayName, "sync complete:", result.newBets, "new,", result.updatedBets, "updated,", result.skippedBets, "unchanged");
  return {
    success: true,
    provider: provider.name,
    newBets: result.newBets,
    updatedBets: result.updatedBets,
    skippedBets: result.skippedBets,
    total: mappedBets.length
  };
}

// ─── Firestore Operations ───

/**
 * Save mapped bets to Firestore with deduplication and change detection.
 * @param {object} db - Firestore database reference
 * @param {string} uid - Firebase user ID
 * @param {Array} mappedBets - Array of mapped bet objects (must have providerBetId)
 */
// eslint-disable-next-line no-unused-vars
async function saveBetsToFirestore(db, uid, mappedBets) {
  const betsRef = db.collection("users").doc(uid).collection("bets");
  let newBets = 0;
  let updatedBets = 0;
  let skippedBets = 0;

  const batchSize = 450;
  for (let i = 0; i < mappedBets.length; i += batchSize) {
    const chunk = mappedBets.slice(i, i + batchSize);
    const batch = db.batch();

    for (const bet of chunk) {
      const docId = bet.providerBetId;
      if (!docId) continue;

      const docRef = betsRef.doc(docId);
      const existing = await docRef.get();

      if (existing.exists) {
        const existingData = existing.data();
        const changed = existingData.statusRaw !== bet.statusRaw ||
                        existingData.actualPayout !== bet.actualPayout ||
                        existingData.potentialPayout !== bet.potentialPayout ||
                        existingData.sportRaw !== bet.sportRaw ||
                        existingData.odds !== bet.odds ||
                        existingData.betTypeRaw !== bet.betTypeRaw ||
                        existingData.eventDescription !== bet.eventDescription;
        if (changed) {
          batch.set(docRef, bet);
          updatedBets++;
        } else {
          skippedBets++;
        }
      } else {
        batch.set(docRef, bet);
        newBets++;
      }
    }

    await batch.commit();
  }

  return { newBets, updatedBets, skippedBets };
}

// ─── Shared Utilities: Sport Detection ───

// eslint-disable-next-line no-unused-vars
const SPORT_KEYWORDS = {
  NFL: ["NFL", "Super Bowl", "NFC", "AFC",
        "Patriots", "Chiefs", "Eagles", "Cowboys", "Packers", "49ers", "Bills",
        "Dolphins", "Ravens", "Bengals", "Lions", "Bears", "Vikings", "Commanders",
        "Saints", "Buccaneers", "Falcons", "Panthers", "Seahawks", "Cardinals", "Rams",
        "Chargers", "Broncos", "Raiders", "Steelers", "Browns", "Colts", "Texans",
        "Jaguars", "Titans", "Jets", "Giants"],
  NBA: ["NBA", "Lakers", "Celtics", "Warriors", "Nets", "Bucks", "76ers", "Heat",
        "Suns", "Mavericks", "Nuggets", "Clippers", "Grizzlies", "Pelicans",
        "Cavaliers", "Knicks", "Bulls", "Hawks", "Raptors", "Hornets", "Wizards",
        "Pacers", "Blazers", "Kings", "Spurs", "Thunder", "Rockets", "Pistons",
        "Magic", "Jazz", "Timberwolves"],
  MLB: ["MLB", "Yankees", "Dodgers", "Red Sox", "Cubs", "Astros", "Braves", "Phillies",
        "Mets", "Cardinals", "Padres", "Mariners", "Guardians", "Rangers", "Orioles",
        "Twins", "Rays", "Blue Jays", "Brewers", "Reds", "Diamondbacks", "Pirates",
        "Rockies", "Tigers", "Royals", "White Sox", "Angels", "Athletics", "Nationals",
        "Marlins"],
  NHL: ["NHL", "Bruins", "Maple Leafs", "Canadiens", "Blackhawks", "Red Wings",
        "Penguins", "Flyers", "Capitals", "Lightning", "Avalanche", "Golden Knights",
        "Oilers", "Flames", "Hurricanes", "Stars", "Blues", "Wild", "Jets",
        "Predators", "Kraken", "Islanders", "Devils", "Senators", "Sabres",
        "Canucks", "Sharks", "Ducks", "Blue Jackets"],
  WNBA: ["WNBA", "Fever", "Sky", "Mercury", "Aces", "Liberty", "Sun", "Storm", "Lynx", "Dream", "Mystics", "Wings", "Sparks"],
  NCAAF: ["NCAAF", "College Football", "Bowl Game", "CFP", "Chanticleers"],
  NCAAB: ["NCAAB", "College Basketball", "March Madness", "NCAA Tournament", "Final Four"],
  Soccer: ["Soccer", "Premier League", "La Liga", "Champions League", "MLS", "EPL", "FIFA World Cup", "World Cup"],
  MMA: ["MMA", "UFC", "Fight Night"],
  Tennis: ["Tennis", "ATP", "WTA", "Wimbledon"],
  Golf: ["Golf", "PGA", "Masters"]
};

// eslint-disable-next-line no-unused-vars
function detectSportFromEvent(eventName, competitionName) {
  if (!eventName && !competitionName) return "Other";
  const upper = ((eventName || "") + " " + (competitionName || "")).toUpperCase();
  for (const [sport, keywords] of Object.entries(SPORT_KEYWORDS)) {
    for (const kw of keywords) {
      if (upper.includes(kw.toUpperCase())) return sport;
    }
  }
  return "Other";
}

// eslint-disable-next-line no-unused-vars
function detectPrimarySport(legs) {
  const counts = {};
  for (const leg of legs) {
    const s = leg.sportRaw || "Other";
    counts[s] = (counts[s] || 0) + 1;
  }
  let best = "Other", max = 0;
  for (const [s, c] of Object.entries(counts)) {
    if (c > max) { max = c; best = s; }
  }
  return best;
}

// ─── Shared Utilities: Bet Type Detection ───

// eslint-disable-next-line no-unused-vars
function detectBetType(legInfo) {
  if (!legInfo) return "Other";
  const m = (legInfo.marketDesc || legInfo.marketDescription || "").toUpperCase();
  const s = (legInfo.selectionName || "").toUpperCase();
  const h = legInfo.handicap || legInfo.line;
  const comp = (legInfo.competitionName || "").toUpperCase();
  const mt = (legInfo.marketType || "").toUpperCase();

  // Season win total bets are Over/Under, not Futures — check BEFORE the Futures gate.
  if (m.includes("SEASON WINS") || m.includes("WIN TOTAL") || m.includes("WINS O/U")) return "Over/Under";

  // Futures
  // Note: "PLAYOFF"/"PLAYOFFS" intentionally excluded from market description check —
  // game bets during the playoffs have these words in their market description and are NOT futures.
  // Futures detection relies on competition name (comp) and market type (mt) instead.
  if (comp.includes("FUTURE") || mt.includes("SEASON") || mt.includes("FUTURE") ||
      mt.includes("CHAMPIONSHIP") || mt.includes("DIVISION") || mt.includes("CONFERENCE") ||
      m.includes("FUTURES") || m.includes("CHAMPION") || m.includes("MVP") ||
      m.includes("DRIVE") || m.includes("WHAT WILL HAPPEN FIRST") ||
      m.includes("REGION") ||
      m.includes("MAKE THE") || m.includes("MISS THE") || m.includes("REACH THE") ||
      m.includes("QUALIFY") || m.includes("RELEGAT") || m.includes("PROMOTED") ||
      m.includes("SEMI-FINAL") || m.includes("SEMIFINAL") || m.includes("SEMI FINAL") ||
      m.includes("QUARTER-FINAL") || m.includes("QUARTERFINAL") || m.includes("QUARTER FINAL")) return "Futures";

  if (m.includes("SPREAD") || m.includes("HANDICAP") || m.includes("POINT SPREAD")) return "Spread";
  if (m.includes("TOTAL") || m.includes("OVER/UNDER") || s.includes("OVER") || s.includes("UNDER")) return "Over/Under";
  if (m.includes("MONEYLINE") || m.includes("MONEY LINE") || m.includes("TO WIN") || m.includes("MATCH RESULT")) return "Moneyline";

  // Quantity-based stat lines → Over/Under
  if (m.includes("YARDS") || m.includes("COMPLETIONS") || m.includes("ATTEMPTS") ||
      m.includes("RECEPTIONS") || m.includes("REBOUNDS") || m.includes("ASSISTS") ||
      m.includes("POINTS") || m.includes("3-POINT") || m.includes("THREE POINT") ||
      m.includes("STEALS") || m.includes("BLOCKS") || m.includes("STRIKEOUTS") ||
      m.includes("HITS") || m.includes("BASES") || m.includes("GOALS") ||
      m.includes("SHOTS") || m.includes("TACKLES") || m.includes("HOME RUNS") ||
      m.includes("PASSING") || m.includes("RUSHING") || m.includes("RECEIVING")) return "Over/Under";

  // Binary player outcomes → Player Prop
  if (m.includes("TOUCHDOWN") || m.includes("TO SCORE") || m.includes("ANYTIME") ||
      m.includes("INTERCEPTION") || m.includes("SACK") || m.includes("ROOKIE") ||
      m.includes("PLAYER") || m.includes("FIRST GOAL") || m.includes("LAST GOAL")) return "Player Prop";
  if (h != null && !m.includes("TOTAL")) return "Spread";
  return "Other";
}

// ─── Shared Utilities: Odds ───

// eslint-disable-next-line no-unused-vars
function decimalToAmerican(d) {
  return d >= 2.0 ? Math.round((d - 1) * 100) : Math.round(-100 / (d - 1));
}

// ─── Shared Utilities: Descriptions ───

// eslint-disable-next-line no-unused-vars
function buildLegDescription(marketDesc, selectionName, handicap) {
  const parts = [];
  if (selectionName) parts.push(selectionName);
  if (marketDesc) parts.push(marketDesc);
  if (handicap != null) {
    const h = parseFloat(handicap);
    parts.push(h >= 0 ? `+${h}` : `${h}`);
  }
  return parts.join(" – ") || "Bet";
}

// eslint-disable-next-line no-unused-vars
function buildBetDescription(legs, isParlay) {
  if (isParlay) return `${legs.length}-Leg Parlay`;
  return legs.length > 0 ? (legs[0].legDescription || "Bet") : "Bet";
}

// ─── Shared Utilities: Date ───

// eslint-disable-next-line no-unused-vars
function parseDate(val) {
  if (!val) return new Date().toISOString();
  if (typeof val === "number") {
    const ts = val > 1e12 ? val : val * 1000;
    return new Date(ts).toISOString();
  }
  const d = new Date(val);
  return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}
