// ─── FanDuel Provider Adapter ───

registerProvider({
  name: "fanduel",
  displayName: "FanDuel",
  tabUrlPattern: "*://*.fanduel.com/*",
  storageKeyPrefix: "fd",
  pageLoadedMessage: "fanduelPageLoaded",

  // The function injected into FanDuel's MAIN world to fetch bets
  fetchBetsFromPage: fetchFanDuelBetsFromPage,

  // Maps raw FanDuel bets to our standard schema
  mapBets: mapFanDuelBets
});

// eslint-disable-next-line no-unused-vars
function mapFanDuelBets(response) {
  const fdBets = response.bets || [];
  return fdBets.map(mapFanDuelBet).filter(bet => bet.providerBetId);
}

function mapFanDuelBet(fdBet) {
  const legs = extractFanDuelLegs(fdBet);
  const isParlay = legs.length > 1;

  return {
    providerBetId: String(fdBet.betId || fdBet.id || ""),
    fanduelBetId: String(fdBet.betId || fdBet.id || ""),  // backward compatibility
    source: "fanduel",
    sportRaw: isParlay ? detectPrimarySport(legs) : (legs[0]?.sportRaw || "Other"),
    betTypeRaw: isParlay ? "Parlay" : (legs[0]?.betTypeRaw || "Other"),
    statusRaw: mapFanDuelBetStatus(fdBet),
    stake: parseFloat(fdBet.currentSize || fdBet.betSize || 0),
    odds: extractFanDuelAmericanOdds(fdBet),
    potentialPayout: extractFanDuelPotentialPayout(fdBet),
    actualPayout: extractFanDuelActualPayout(fdBet),
    betDescription: buildBetDescription(legs, isParlay),
    notes: null,
    eventDate: parseDate(fdBet.placedDate || fdBet.createdDate),
    eventDescription: legs[0]?.eventDescription || null,
    createdAt: parseDate(fdBet.placedDate || fdBet.createdDate),
    updatedAt: parseDate(fdBet.settledDate || fdBet.lastModifiedDate || fdBet.placedDate),
    legs: isParlay ? legs : [],
    syncedAt: new Date().toISOString()
  };
}

function extractFanDuelLegs(fdBet) {
  const rawLegs = fdBet.legs || fdBet.betLegs || fdBet.selections || [];
  return rawLegs.map(leg => {
    const parts = leg.parts || leg.selections || [leg];
    const firstPart = parts[0] || leg;
    const eventName = firstPart.eventDescription || firstPart.eventName || firstPart.event?.name || "";
    const marketDesc = firstPart.eventMarketDescription || firstPart.marketDescription || firstPart.market?.name || "";
    const selectionName = firstPart.selectionName || firstPart.outcome?.name || firstPart.outcomeName || "";
    const handicap = firstPart.handicap || firstPart.line || null;
    const competitionName = firstPart.competitionName || "";
    const marketType = firstPart.marketType || "";

    return {
      sportRaw: detectSportFromEvent(eventName, competitionName),
      betTypeRaw: detectBetType({ marketDesc, selectionName, handicap, competitionName, marketType }),
      resultRaw: mapFanDuelLegResult(leg),
      legDescription: buildLegDescription(marketDesc, selectionName, handicap),
      odds: extractFanDuelLegOdds(leg),
      eventDescription: eventName || null
    };
  });
}

function mapFanDuelBetStatus(fdBet) {
  const resultType = (fdBet.result?.type || fdBet.betResult || fdBet.resultType || "").toString();
  if (resultType) {
    const n = resultType.toUpperCase().replace(/[^A-Z]/g, "");
    const resultMap = {
      WON: "Won", WIN: "Won", WINNER: "Won",
      LOST: "Lost", LOSE: "Lost", LOSER: "Lost",
      PUSH: "Push", PUSHED: "Push",
      VOID: "Void", VOIDED: "Void", CANCELLED: "Void", CANCELED: "Void",
      CASHEDOUT: "Cashed Out", CASHOUT: "Cashed Out"
    };
    if (resultMap[n]) return resultMap[n];
  }

  // Detect cash-out by cashoutAmount before falling back to pandl-based classification.
  // FanDuel may not always set result.type = CASHEDOUT on cashed-out bets.
  if (fdBet.cashoutAmount != null && parseFloat(fdBet.cashoutAmount) > 0) {
    return "Cashed Out";
  }

  if (fdBet.isSettled === true) {
    const pandl = parseFloat(fdBet.pandl);
    if (!isNaN(pandl)) {
      if (pandl > 0) return "Won";
      if (pandl < 0) return "Lost";
      const ops = fdBet.operationInfo || [];
      const hasReturn = ops.some(op => {
        const t = (op.operationType || "").toUpperCase();
        return t !== "PLACEMENT" && t !== "";
      });
      if (hasReturn) return "Push";
      return "Lost";
    }
    return "Lost";
  }

  return "Pending";
}

function mapFanDuelLegResult(leg) {
  const result = leg.result?.type || leg.resultType || leg.status || "";
  const n = result.toUpperCase().replace(/[^A-Z]/g, "");
  const map = {
    WON: "Won", WIN: "Won", LOST: "Lost", LOSE: "Lost",
    PUSH: "Push", VOID: "Void", VOIDED: "Void",
    PENDING: "Pending", OPEN: "Pending"
  };
  return map[n] || "Pending";
}

// ─── FanDuel Odds ───

function extractFanDuelAmericanOdds(fdBet) {
  const odds = fdBet.currentPrice?.americanOdds || fdBet.americanOdds || fdBet.price?.americanOdds;
  if (odds != null) return parseInt(odds, 10);

  const dec = fdBet.currentPrice?.decimal || fdBet.decimalOdds;
  if (dec != null) return decimalToAmerican(parseFloat(dec));

  const legs = fdBet.legs || [];
  if (legs.length === 0) return -110;

  if (legs.length === 1) {
    const parts = legs[0].parts || [];
    if (parts.length > 0 && parts[0].americanPrice != null) {
      return parseInt(parts[0].americanPrice, 10);
    }
  }

  let combinedDecimalOdds = 1;
  let foundAny = false;
  for (const leg of legs) {
    const parts = leg.parts || [];
    for (const part of parts) {
      const decPrice = parseFloat(part.originalPrice || part.price || 0);
      if (decPrice > 0) {
        combinedDecimalOdds *= decPrice;
        foundAny = true;
      }
    }
  }

  if (foundAny && combinedDecimalOdds > 1) {
    return decimalToAmerican(combinedDecimalOdds);
  }

  return -110;
}

function extractFanDuelLegOdds(leg) {
  const parts = leg.parts || [leg];
  const p = parts[0] || leg;
  if (p.americanPrice != null) return parseInt(p.americanPrice, 10);
  const odds = p.currentPrice?.americanOdds || p.americanOdds;
  if (odds != null) return parseInt(odds, 10);
  if (p.price != null && typeof p.price === "string" && !isNaN(parseFloat(p.price))) {
    return decimalToAmerican(parseFloat(p.price));
  }
  const dec = p.currentPrice?.decimal;
  if (dec != null) return decimalToAmerican(parseFloat(dec));
  return -110;
}

// ─── FanDuel Payout ───

function extractFanDuelPotentialPayout(fdBet) {
  const preCalc = parseFloat(fdBet.originalPotentialWin || fdBet.potentialWin || fdBet.currentPotentialWin || 0);
  if (preCalc > 0) return preCalc;

  const stake = parseFloat(fdBet.currentSize || fdBet.betSize || 0);
  const legs = fdBet.legs || [];
  if (legs.length === 0 || stake === 0) return 0;

  let combinedDecimalOdds = 1;
  for (const leg of legs) {
    const parts = leg.parts || [];
    for (const part of parts) {
      const decPrice = parseFloat(part.originalPrice || part.price || 0);
      if (decPrice > 0) {
        combinedDecimalOdds *= decPrice;
      }
    }
  }

  return Math.round(stake * combinedDecimalOdds * 100) / 100;
}

function extractFanDuelActualPayout(fdBet) {
  if (fdBet.isSettled === false) return null;

  const stake = parseFloat(fdBet.currentSize || fdBet.betSize || 0);
  const pandl = parseFloat(fdBet.pandl);

  if (fdBet.isSettled === true && !isNaN(pandl)) {
    if (pandl > 0) return pandl;
    if (pandl < 0) return 0;
    const status = mapFanDuelBetStatus(fdBet);
    if (status === "Push") return stake;
    return 0;
  }

  const status = mapFanDuelBetStatus(fdBet);
  if (status === "Pending") return null;
  if (status === "Won") {
    const s = fdBet.result?.currentSettle || fdBet.settledAmount || fdBet.payout;
    return s != null ? parseFloat(s) : null;
  }
  if (status === "Cashed Out") {
    const c = fdBet.cashoutAmount || fdBet.result?.currentSettle;
    return c != null ? parseFloat(c) : Math.max(0, stake + (pandl || 0));
  }
  if (status === "Push") return stake;
  if (status === "Lost") return 0;
  return null;
}

// ─── FanDuel Page Script (MAIN World) ───
// This function runs via chrome.scripting.executeScript in FanDuel's page context.
// IMPORTANT: Must be entirely self-contained — no external references.

async function fetchFanDuelBetsFromPage(capturedAuthHeaders) {
  const LOG = "[Wysely]";

  async function fetchWithTimeout(url, options, timeoutMs = 10000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const resp = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timer);
      return resp;
    } catch (e) {
      clearTimeout(timer);
      throw e;
    }
  }

  try {
    // ── Detect state from URL ──
    const hostname = window.location.hostname;
    const parts = hostname.split(".");
    const sbIndex = parts.indexOf("sportsbook");
    let detectedState = "nj";

    if (sbIndex > 0) {
      const candidate = parts[sbIndex - 1];
      if (/^[a-z]{2}$/.test(candidate) && candidate !== "sb") {
        detectedState = candidate;
      }
    }
    console.log(LOG, "Detected state:", detectedState);

    // ── Extract auth token from session-sportsbook ──
    let authToken = null;
    try {
      const sessionData = localStorage.getItem("session-sportsbook");
      if (sessionData) {
        const parsed = JSON.parse(sessionData);
        authToken = (parsed.authToken && parsed.authToken.jwt) || parsed.token || null;
        if (authToken) console.log(LOG, "Auth token found, length=" + authToken.length);
        if (parsed.expires) {
          const exp = new Date(parsed.expires);
          const now = new Date();
          console.log(LOG, "Session expires:", parsed.expires,
                      now > exp ? "(EXPIRED " + Math.round((now - exp) / 60000) + "m ago)" : "(valid)");
        }
      }
    } catch (e) {
      console.log(LOG, "session-sportsbook error:", e.message);
    }

    if (!authToken) {
      return { success: false, error: "No FanDuel auth token found. Make sure you're logged into FanDuel." };
    }

    // ── Get PerimeterX context token ──
    let pxContext = null;
    try {
      pxContext = localStorage.getItem("x-px-context") || null;
    } catch (e) {}

    // ── Build request headers ──
    const APP_KEY = "FhMFpcPWXMeyZxOx";
    const headers = {
      "Accept": "application/json",
      "X-Authentication": authToken,
      "X-Application": APP_KEY,
      "X-Sportsbook-Region": detectedState.toUpperCase(),
      "X-App-Version": "2.138.3"
    };
    if (pxContext) {
      headers["x-px-context"] = pxContext;
    }

    // ── Test the API ──
    const baseUrl = "https://api.sportsbook.fanduel.com/sbapi";
    const testUrl = baseUrl + "/fetch-my-bets?isSettled=false&fromRecord=1&toRecord=1&sortDir=DESC&sortParam=PLACEMENT_DATE&adaptiveTokenEnabled=true&_ak=" + APP_KEY;

    const testResp = await fetchWithTimeout(testUrl, { method: "GET", headers: headers });
    if (!testResp.ok) {
      return {
        success: false,
        error: "FanDuel API returned HTTP " + testResp.status + ". " +
               (testResp.status === 401 ? "Auth token may be expired. Refresh the FanDuel page and try again." :
                testResp.status === 403 ? "Access denied." : "Check the FanDuel tab console.")
      };
    }

    const ct = testResp.headers.get("content-type") || "";
    if (!ct.includes("json")) {
      return { success: false, error: "FanDuel returned non-JSON response." };
    }

    // ── Fetch all bets ──
    const openBets = await fetchAllBets(baseUrl, false, headers, APP_KEY);
    const settledBets = await fetchAllBets(baseUrl, true, headers, APP_KEY);
    const allBets = [...openBets, ...settledBets];

    console.log(LOG, "Done!", openBets.length, "open,", settledBets.length, "settled,", allBets.length, "total");

    return {
      success: true,
      bets: allBets,
      summary: { settled: settledBets.length, open: openBets.length, total: allBets.length }
    };

  } catch (error) {
    console.error(LOG, error);
    return { success: false, error: error.message };
  }

  async function fetchAllBets(baseUrl, isSettled, headers, appKey) {
    const allBets = [];
    let fromRecord = 1;
    const pageSize = 20;
    let hasMore = true;
    const sortParam = isSettled ? "SETTLEMENT_DATE" : "PLACEMENT_DATE";

    while (hasMore) {
      const toRecord = fromRecord + pageSize - 1;
      const url = baseUrl + "/fetch-my-bets?isSettled=" + isSettled +
                  "&fromRecord=" + fromRecord + "&toRecord=" + toRecord +
                  "&sortDir=DESC&sortParam=" + sortParam +
                  "&adaptiveTokenEnabled=true&_ak=" + appKey;

      const resp = await fetchWithTimeout(url, { method: "GET", headers: headers }, 15000);
      if (!resp.ok) throw new Error("FanDuel API error: HTTP " + resp.status);

      const respCt = resp.headers.get("content-type") || "";
      if (!respCt.includes("json")) throw new Error("Non-JSON response");

      const data = await resp.json();
      const bets = data.bets || data.openBets || data.settledBets || data.myBets || [];
      if (Array.isArray(bets) && bets.length > 0) {
        allBets.push(...bets);
        fromRecord += bets.length;
        const totalResults = data.totalResults || data.totalCount || data.total || 0;
        if (totalResults > 0) {
          hasMore = fromRecord <= totalResults;
        } else {
          hasMore = bets.length === pageSize;
        }
      } else {
        hasMore = false;
      }

      if (fromRecord > 1000) hasMore = false;
    }

    return allBets;
  }
}
